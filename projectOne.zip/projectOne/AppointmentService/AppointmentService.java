import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class AppointmentService {
    private final Map<String, Appointment> appointments;

    public AppointmentService() {
        appointments = new HashMap<>();
    }

    public boolean addAppointment(Appointment appointment) {
        if (appointment == null) {
            throw new IllegalArgumentException("Appointment cannot be null");
        }

        if (appointments.containsKey(appointment.getAppointmentId())) {
            throw new IllegalArgumentException("Duplicate ID");
        }

        appointments.put(appointment.getAppointmentId(), appointment);
        return true;
    }

    public boolean deleteAppointment(String appointmentId) {
        if (!appointments.containsKey(appointmentId)) {
            return false;
        }

        appointments.remove(appointmentId);
        return true;
    }

    public boolean updateAppointmentDate(String appointmentId, Date appointmentDate) {
        Appointment appointment = appointments.get(appointmentId);

        if (appointment == null) {
            return false;
        }

        appointment.setAppointmentDate(appointmentDate);
        return true;
    }

    public boolean updateDescription(String appointmentId, String description) {
        Appointment appointment = appointments.get(appointmentId);

        if (appointment == null) {
            return false;
        }

        appointment.setDescription(description);
        return true;
    }

    public Appointment getAppointment(String appointmentId) {
        return appointments.get(appointmentId);
    }
}