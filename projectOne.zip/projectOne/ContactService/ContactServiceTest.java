import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class ContactServiceTest {
    private ContactService contactService;
    private Contact contact;

    @BeforeEach
    public void setUp() {
        contactService = new ContactService();
        contact = new Contact("12345", "Anthony", "Smith", "1234567890", "123 Main Street");
    }

    @Test
    public void testAddContactSuccessfully() {
        assertTrue(contactService.addContact(contact));
        assertEquals(contact, contactService.getContact("12345"));
    }

    @Test
    public void testAddContactWithUniqueIdOnly() {
        Contact duplicateContact = new Contact("12345", "John", "Jones", "0987654321", "456 Oak Road");

        assertTrue(contactService.addContact(contact));

        assertThrows(IllegalArgumentException.class, () -> {
            contactService.addContact(duplicateContact);
        });
    }

    @Test
    public void testAddNullContactThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> {
            contactService.addContact(null);
        });
    }

    @Test
    public void testDeleteContactSuccessfully() {
        contactService.addContact(contact);

        assertTrue(contactService.deleteContact("12345"));
        assertNull(contactService.getContact("12345"));
    }

    @Test
    public void testDeleteContactThatDoesNotExist() {
        assertFalse(contactService.deleteContact("99999"));
    }

    @Test
    public void testUpdateFirstNameSuccessfully() {
        contactService.addContact(contact);

        assertTrue(contactService.updateFirstName("12345", "John"));
        assertEquals("John", contactService.getContact("12345").getFirstName());
    }

    @Test
    public void testUpdateLastNameSuccessfully() {
        contactService.addContact(contact);

        assertTrue(contactService.updateLastName("12345", "Jones"));
        assertEquals("Jones", contactService.getContact("12345").getLastName());
    }

    @Test
    public void testUpdatePhoneSuccessfully() {
        contactService.addContact(contact);

        assertTrue(contactService.updatePhone("12345", "0987654321"));
        assertEquals("0987654321", contactService.getContact("12345").getPhone());
    }

    @Test
    public void testUpdateAddressSuccessfully() {
        contactService.addContact(contact);

        assertTrue(contactService.updateAddress("12345", "456 Oak Road"));
        assertEquals("456 Oak Road", contactService.getContact("12345").getAddress());
    }

    @Test
    public void testUpdateFirstNameForNonexistentContact() {
        assertFalse(contactService.updateFirstName("99999", "John"));
    }

    @Test
    public void testUpdateLastNameForNonexistentContact() {
        assertFalse(contactService.updateLastName("99999", "Jones"));
    }

    @Test
    public void testUpdatePhoneForNonexistentContact() {
        assertFalse(contactService.updatePhone("99999", "0987654321"));
    }

    @Test
    public void testUpdateAddressForNonexistentContact() {
        assertFalse(contactService.updateAddress("99999", "456 Oak Road"));
    }

    @Test
    public void testUpdateFirstNameWithInvalidValue() {
        contactService.addContact(contact);

        assertThrows(IllegalArgumentException.class, () -> {
            contactService.updateFirstName("12345", "AnthonyLong");
        });
    }

    @Test
    public void testUpdateLastNameWithInvalidValue() {
        contactService.addContact(contact);

        assertThrows(IllegalArgumentException.class, () -> {
            contactService.updateLastName("12345", "SmithLonger");
        });
    }

    @Test
    public void testUpdatePhoneWithInvalidValue() {
        contactService.addContact(contact);

        assertThrows(IllegalArgumentException.class, () -> {
            contactService.updatePhone("12345", "12345");
        });
    }

    @Test
    public void testUpdateAddressWithInvalidValue() {
        contactService.addContact(contact);

        assertThrows(IllegalArgumentException.class, () -> {
            contactService.updateAddress("12345", "1234567890123456789012345678901");
        });
    }
}