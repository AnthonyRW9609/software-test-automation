import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class ContactTest {

    @Test
    public void testContactCreatedSuccessfully() {
        Contact contact = new Contact("1234567890", "Anthony", "Smith", "1234567890", "123 Main Street");

        assertEquals("1234567890", contact.getContactId());
        assertEquals("Anthony", contact.getFirstName());
        assertEquals("Smith", contact.getLastName());
        assertEquals("1234567890", contact.getPhone());
        assertEquals("123 Main Street", contact.getAddress());
    }

    @Test
    public void testContactIdCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact(null, "Anthony", "Smith", "1234567890", "123 Main Street");
        });
    }

    @Test
    public void testContactIdCannotBeLongerThanTenCharacters() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345678901", "Anthony", "Smith", "1234567890", "123 Main Street");
        });
    }

    @Test
    public void testFirstNameCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", null, "Smith", "1234567890", "123 Main Street");
        });
    }

    @Test
    public void testFirstNameCannotBeLongerThanTenCharacters() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "AnthonyLong", "Smith", "1234567890", "123 Main Street");
        });
    }

    @Test
    public void testLastNameCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Anthony", null, "1234567890", "123 Main Street");
        });
    }

    @Test
    public void testLastNameCannotBeLongerThanTenCharacters() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Anthony", "SmithLonger", "1234567890", "123 Main Street");
        });
    }

    @Test
    public void testPhoneCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Anthony", "Smith", null, "123 Main Street");
        });
    }

    @Test
    public void testPhoneMustBeExactlyTenDigitsTooShort() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Anthony", "Smith", "123456789", "123 Main Street");
        });
    }

    @Test
    public void testPhoneMustBeExactlyTenDigitsTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Anthony", "Smith", "12345678901", "123 Main Street");
        });
    }

    @Test
    public void testPhoneMustContainOnlyDigits() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Anthony", "Smith", "12345abcde", "123 Main Street");
        });
    }

    @Test
    public void testAddressCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Anthony", "Smith", "1234567890", null);
        });
    }

    @Test
    public void testAddressCannotBeLongerThanThirtyCharacters() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Anthony", "Smith", "1234567890", "1234567890123456789012345678901");
        });
    }

    @Test
    public void testFirstNameCanBeUpdated() {
        Contact contact = new Contact("12345", "Anthony", "Smith", "1234567890", "123 Main Street");

        contact.setFirstName("John");

        assertEquals("John", contact.getFirstName());
    }

    @Test
    public void testLastNameCanBeUpdated() {
        Contact contact = new Contact("12345", "Anthony", "Smith", "1234567890", "123 Main Street");

        contact.setLastName("Jones");

        assertEquals("Jones", contact.getLastName());
    }

    @Test
    public void testPhoneCanBeUpdated() {
        Contact contact = new Contact("12345", "Anthony", "Smith", "1234567890", "123 Main Street");

        contact.setPhone("0987654321");

        assertEquals("0987654321", contact.getPhone());
    }

    @Test
    public void testAddressCanBeUpdated() {
        Contact contact = new Contact("12345", "Anthony", "Smith", "1234567890", "123 Main Street");

        contact.setAddress("456 Oak Road");

        assertEquals("456 Oak Road", contact.getAddress());
    }
}