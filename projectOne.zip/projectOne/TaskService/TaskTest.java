import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class TaskTest {

    @Test
    public void testTaskCreatedSuccessfully() {
        Task task = new Task("1234567890", "Homework", "Complete software testing assignment");

        assertEquals("1234567890", task.getTaskId());
        assertEquals("Homework", task.getName());
        assertEquals("Complete software testing assignment", task.getDescription());
    }

    @Test
    public void testTaskIdCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task(null, "Homework", "Complete software testing assignment");
        });
    }

    @Test
    public void testTaskIdCannotBeLongerThanTenCharacters() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345678901", "Homework", "Complete software testing assignment");
        });
    }

    @Test
    public void testNameCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345", null, "Complete software testing assignment");
        });
    }

    @Test
    public void testNameCannotBeLongerThanTwentyCharacters() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345", "ThisNameIsWayTooLong", "Complete software testing assignment");
        });
    }

    @Test
    public void testDescriptionCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345", "Homework", null);
        });
    }

    @Test
    public void testDescriptionCannotBeLongerThanFiftyCharacters() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345", "Homework", "This description is intentionally longer than fifty characters total.");
        });
    }

    @Test
    public void testNameCanBeUpdated() {
        Task task = new Task("12345", "Homework", "Complete software testing assignment");

        task.setName("Project");

        assertEquals("Project", task.getName());
    }

    @Test
    public void testDescriptionCanBeUpdated() {
        Task task = new Task("12345", "Homework", "Complete software testing assignment");

        task.setDescription("Complete JUnit tests");

        assertEquals("Complete JUnit tests", task.getDescription());
    }

    @Test
    public void testUpdatedNameCannotBeNull() {
        Task task = new Task("12345", "Homework", "Complete software testing assignment");

        assertThrows(IllegalArgumentException.class, () -> {
            task.setName(null);
        });
    }

    @Test
    public void testUpdatedNameCannotBeLongerThanTwentyCharacters() {
        Task task = new Task("12345", "Homework", "Complete software testing assignment");

        assertThrows(IllegalArgumentException.class, () -> {
            task.setName("ThisNameIsWayTooLong");
        });
    }

    @Test
    public void testUpdatedDescriptionCannotBeNull() {
        Task task = new Task("12345", "Homework", "Complete software testing assignment");

        assertThrows(IllegalArgumentException.class, () -> {
            task.setDescription(null);
        });
    }

    @Test
    public void testUpdatedDescriptionCannotBeLongerThanFiftyCharacters() {
        Task task = new Task("12345", "Homework", "Complete software testing assignment");

        assertThrows(IllegalArgumentException.class, () -> {
            task.setDescription("This description is intentionally longer than fifty characters total.");
        });
    }
}