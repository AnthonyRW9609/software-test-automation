import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class TaskServiceTest {
    private TaskService taskService;
    private Task task;

    @BeforeEach
    public void setUp() {
        taskService = new TaskService();
        task = new Task("12345", "Homework", "Complete software testing assignment");
    }

    @Test
    public void testAddTaskSuccessfully() {
        assertTrue(taskService.addTask(task));
        assertEquals(task, taskService.getTask("12345"));
    }

    @Test
    public void testAddTaskWithUniqueIdOnly() {
        Task duplicateTask = new Task("12345", "Project", "Complete JUnit testing project");

        assertTrue(taskService.addTask(task));

        assertThrows(IllegalArgumentException.class, () -> {
            taskService.addTask(duplicateTask);
        });
    }

    @Test
    public void testAddNullTaskThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> {
            taskService.addTask(null);
        });
    }

    @Test
    public void testDeleteTaskSuccessfully() {
        taskService.addTask(task);

        assertTrue(taskService.deleteTask("12345"));
        assertNull(taskService.getTask("12345"));
    }

    @Test
    public void testDeleteTaskThatDoesNotExist() {
        assertFalse(taskService.deleteTask("99999"));
    }

    @Test
    public void testUpdateNameSuccessfully() {
        taskService.addTask(task);

        assertTrue(taskService.updateName("12345", "Project"));
        assertEquals("Project", taskService.getTask("12345").getName());
    }

    @Test
    public void testUpdateDescriptionSuccessfully() {
        taskService.addTask(task);

        assertTrue(taskService.updateDescription("12345", "Complete JUnit tests"));
        assertEquals("Complete JUnit tests", taskService.getTask("12345").getDescription());
    }

    @Test
    public void testUpdateNameForNonexistentTask() {
        assertFalse(taskService.updateName("99999", "Project"));
    }

    @Test
    public void testUpdateDescriptionForNonexistentTask() {
        assertFalse(taskService.updateDescription("99999", "Complete JUnit tests"));
    }

    @Test
    public void testUpdateNameWithInvalidValue() {
        taskService.addTask(task);

        assertThrows(IllegalArgumentException.class, () -> {
            taskService.updateName("12345", "ThisNameIsWayTooLong");
        });
    }

    @Test
    public void testUpdateDescriptionWithInvalidValue() {
        taskService.addTask(task);

        assertThrows(IllegalArgumentException.class, () -> {
            taskService.updateDescription("12345", "This description is intentionally longer than fifty characters total.");
        });
    }
}