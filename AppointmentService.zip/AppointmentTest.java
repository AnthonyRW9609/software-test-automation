package appointmentserviceproject;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.Test;

public class AppointmentTest {

    private Date getFutureDate() {
        return new Date(System.currentTimeMillis() + 86400000);
    }

    private Date getLaterFutureDate() {
        return new Date(System.currentTimeMillis() + 172800000);
    }

    private Date getPastDate() {
        return new Date(System.currentTimeMillis() - 86400000);
    }

    @Test
    public void testAppointmentCreatedSuccessfully() {
        Date futureDate = getFutureDate();
        Appointment appointment = new Appointment("1234567890", futureDate, "Doctor appointment");

        assertEquals("1234567890", appointment.getAppointmentId());
        assertEquals(futureDate, appointment.getAppointmentDate());
        assertEquals("Doctor appointment", appointment.getDescription());
    }

    @Test
    public void testAppointmentIdCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(null, getFutureDate(), "Doctor appointment");
        });
    }

    @Test
    public void testAppointmentIdCannotBeLongerThanTenCharacters() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345678901", getFutureDate(), "Doctor appointment");
        });
    }

    @Test
    public void testAppointmentDateCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345", null, "Doctor appointment");
        });
    }

    @Test
    public void testAppointmentDateCannotBeInPast() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345", getPastDate(), "Doctor appointment");
        });
    }

    @Test
    public void testDescriptionCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345", getFutureDate(), null);
        });
    }

    @Test
    public void testDescriptionCannotBeLongerThanFiftyCharacters() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345", getFutureDate(), "This description is intentionally longer than fifty characters total.");
        });
    }

    @Test
    public void testAppointmentDateCanBeUpdated() {
        Appointment appointment = new Appointment("12345", getFutureDate(), "Doctor appointment");
        Date newFutureDate = getLaterFutureDate();

        appointment.setAppointmentDate(newFutureDate);

        assertEquals(newFutureDate, appointment.getAppointmentDate());
    }

    @Test
    public void testUpdatedAppointmentDateCannotBeNull() {
        Appointment appointment = new Appointment("12345", getFutureDate(), "Doctor appointment");

        assertThrows(IllegalArgumentException.class, () -> {
            appointment.setAppointmentDate(null);
        });
    }

    @Test
    public void testUpdatedAppointmentDateCannotBeInPast() {
        Appointment appointment = new Appointment("12345", getFutureDate(), "Doctor appointment");

        assertThrows(IllegalArgumentException.class, () -> {
            appointment.setAppointmentDate(getPastDate());
        });
    }

    @Test
    public void testDescriptionCanBeUpdated() {
        Appointment appointment = new Appointment("12345", getFutureDate(), "Doctor appointment");

        appointment.setDescription("Dental appointment");

        assertEquals("Dental appointment", appointment.getDescription());
    }

    @Test
    public void testUpdatedDescriptionCannotBeNull() {
        Appointment appointment = new Appointment("12345", getFutureDate(), "Doctor appointment");

        assertThrows(IllegalArgumentException.class, () -> {
            appointment.setDescription(null);
        });
    }

    @Test
    public void testUpdatedDescriptionCannotBeLongerThanFiftyCharacters() {
        Appointment appointment = new Appointment("12345", getFutureDate(), "Doctor appointment");

        assertThrows(IllegalArgumentException.class, () -> {
            appointment.setDescription("This description is intentionally longer than fifty characters total.");
        });
    }
}