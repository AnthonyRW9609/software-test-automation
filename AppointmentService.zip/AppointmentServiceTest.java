package appointmentserviceproject;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class AppointmentServiceTest {
    private AppointmentService appointmentService;
    private Appointment appointment;

    private Date getFutureDate() {
        return new Date(System.currentTimeMillis() + 86400000);
    }

    private Date getLaterFutureDate() {
        return new Date(System.currentTimeMillis() + 172800000);
    }

    private Date getPastDate() {
        return new Date(System.currentTimeMillis() - 86400000);
    }

    @BeforeEach
    public void setUp() {
        appointmentService = new AppointmentService();
        appointment = new Appointment("12345", getFutureDate(), "Doctor appointment");
    }

    @Test
    public void testAddAppointmentSuccessfully() {
        assertTrue(appointmentService.addAppointment(appointment));
        assertEquals(appointment, appointmentService.getAppointment("12345"));
    }

    @Test
    public void testAddAppointmentWithUniqueIdOnly() {
        Appointment duplicateAppointment = new Appointment("12345", getFutureDate(), "Dental appointment");

        assertTrue(appointmentService.addAppointment(appointment));

        assertThrows(IllegalArgumentException.class, () -> {
            appointmentService.addAppointment(duplicateAppointment);
        });
    }

    @Test
    public void testAddNullAppointmentThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> {
            appointmentService.addAppointment(null);
        });
    }

    @Test
    public void testDeleteAppointmentSuccessfully() {
        appointmentService.addAppointment(appointment);

        assertTrue(appointmentService.deleteAppointment("12345"));
        assertNull(appointmentService.getAppointment("12345"));
    }

    @Test
    public void testDeleteAppointmentThatDoesNotExist() {
        assertFalse(appointmentService.deleteAppointment("99999"));
    }

    @Test
    public void testUpdateAppointmentDateSuccessfully() {
        appointmentService.addAppointment(appointment);
        Date newFutureDate = getLaterFutureDate();

        assertTrue(appointmentService.updateAppointmentDate("12345", newFutureDate));
        assertEquals(newFutureDate, appointmentService.getAppointment("12345").getAppointmentDate());
    }

    @Test
    public void testUpdateDescriptionSuccessfully() {
        appointmentService.addAppointment(appointment);

        assertTrue(appointmentService.updateDescription("12345", "Dental appointment"));
        assertEquals("Dental appointment", appointmentService.getAppointment("12345").getDescription());
    }

    @Test
    public void testUpdateAppointmentDateForNonexistentAppointment() {
        assertFalse(appointmentService.updateAppointmentDate("99999", getFutureDate()));
    }

    @Test
    public void testUpdateDescriptionForNonexistentAppointment() {
        assertFalse(appointmentService.updateDescription("99999", "Dental appointment"));
    }

    @Test
    public void testUpdateAppointmentDateWithInvalidValue() {
        appointmentService.addAppointment(appointment);

        assertThrows(IllegalArgumentException.class, () -> {
            appointmentService.updateAppointmentDate("12345", getPastDate());
        });
    }

    @Test
    public void testUpdateDescriptionWithInvalidValue() {
        appointmentService.addAppointment(appointment);

        assertThrows(IllegalArgumentException.class, () -> {
            appointmentService.updateDescription("12345", "This description is intentionally longer than fifty characters total.");
        });
    }
}